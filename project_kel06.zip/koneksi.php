<?php
    $conn=mysqli_connect("localhost","root","","dts_webdev");
    if($conn){
        //echo "berhasil";
    }else{
        //echo "gagal";
    }
?>